class UrlsController < ApplicationController
end
